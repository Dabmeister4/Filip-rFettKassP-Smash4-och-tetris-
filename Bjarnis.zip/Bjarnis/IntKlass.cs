﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bjarnis
{
    class IntKlass
    {
        int number = 1;

        public int Doubler()
        {
            return number * 2;
        }
    }
}
