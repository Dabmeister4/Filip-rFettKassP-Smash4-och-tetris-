﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bjarnis
{
    class Program
    {
        static void Main(string[] args)
        {
            BjarnisKlass bjarnisKlass = new BjarnisKlass();
            bjarnisKlass.Run();

        }
    }
}
